<?php
phpinfo()
?>